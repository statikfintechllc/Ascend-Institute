# agent_core/tool_executor.py

import asyncio
from datetime import datetime
from scraper.scraper_loop import get_dom_html
from nlp_engine.transformer_core import encode
from memory.vector_store.embedder import package_embedding
from trading_core.signal_generator import generate_signals
from self_training.feedback_loop import inject_feedback
from agent_shell.shell_executor import run_shell_command
from tools.reward_model import evaluate_result, log_reward
from memory.log_history import log_event
from backend.globals import logger


def execute_tool(task):
    task_type = task.get("type")
    target = task.get("target", "")
    meta = task.get("meta", {})
    timestamp = datetime.utcnow().isoformat()

    try:
        logger.info(f"[TOOL] Executing task: {task_type}")

        if task_type == "scrape":
            dom = asyncio.run(get_dom_html(target))
            preview = dom[:100]
            result = {"scraped": preview}
            reward = evaluate_result(task_type, preview)
            log_reward(reward)
            vector = encode(preview)
            package_embedding(
                preview, vector, {"task": task_type, "timestamp": timestamp}
            )
            log_event(
                "exec", task_type, {"preview": preview}, status="success", meta=reward
            )
            return result

        elif task_type == "signal_scan":
            signals = generate_signals()
            result = {"signals": signals}
            reward = evaluate_result(task_type, str(signals))
            log_reward(reward)
            vector = encode(str(signals))
            package_embedding(
                str(signals), vector, {"task": task_type, "timestamp": timestamp}
            )
            log_event(
                "exec", task_type, {"signals": signals}, status="success", meta=reward
            )
            return result

        elif task_type == "nlp":
            vec = encode(target)
            vector_list = vec.tolist()
            package_embedding(
                target,
                vec,
                {
                    "origin": "tool_executor",
                    "task_type": task_type,
                    "timestamp": timestamp,
                },
            )
            result = {"embedding": vector_list}
            reward = evaluate_result(task_type, target)
            log_reward(reward)
            log_event(
                "exec", task_type, {"embedded": True}, status="success", meta=reward
            )
            return result

        elif task_type == "self_train":
            inject_feedback()
            result = {"trained": True}
            log_event(
                "exec",
                task_type,
                result,
                status="success",
                meta={"timestamp": timestamp},
            )
            return result

        elif task_type == "shell":
            output = run_shell_command(task["command"])
            preview = output[:500]
            reward = evaluate_result(task_type, preview)
            log_reward(reward)
            vector = encode(preview)
            package_embedding(
                preview, vector, {"task": task_type, "timestamp": timestamp}
            )
            result = {"shell_result": preview}
            log_event("exec", task_type, result, status="success", meta=reward)
            return result

        else:
            error_msg = f"Unknown task type: {task_type}"
            logger.error(f"[TOOL] {error_msg}")
            log_event(
                "exec", task_type, {"error": error_msg}, status="error", meta=meta
            )
            raise ValueError(error_msg)

    except Exception as e:
        logger.error(f"[TOOL] Execution error for {task_type}: {e}")
        log_event("exec", task_type, {"error": str(e)}, status="failure", meta=meta)
        return {"error": str(e), "success": False}
